package Sprint2;

public class Acao {

	private String descricao;
	private String plano;
	private String dataEntrada;
	private String dataPrevista;
	private String dataConclusao;
	private int prioridade;
	
	
	public Acao(String descricao, String plano, String dataEntrada, String dataPrevista, String dataConclusao,
			int prioridade) {
		super();
		this.descricao = descricao;
		this.plano = plano;
		this.dataEntrada = dataEntrada;
		this.dataPrevista = dataPrevista;
		this.dataConclusao = dataConclusao;
		this.prioridade = prioridade;
	}


	
	
	
}
