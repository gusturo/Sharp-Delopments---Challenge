package Sprint2;

public class Cliente {

	long cpf;
	String nome;
	String dataNasc;
	String origemDoContato;
	
	
	public Cliente(long cpf, String nome, String dataNasc, String origemDoContato) {
		super();
		this.cpf = cpf;
		this.nome = nome;
		this.dataNasc = dataNasc;
		this.origemDoContato = origemDoContato;
	}
	
	
	
}
