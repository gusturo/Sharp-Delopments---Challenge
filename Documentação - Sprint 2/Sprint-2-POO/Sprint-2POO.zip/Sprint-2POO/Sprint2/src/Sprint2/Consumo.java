package Sprint2;

public class Consumo {

	private double quantidade;
	private String data;
	private String fonteDeConsumo;
	
	
	public Consumo(double quantidade, String data, String fonteDeConsumo) {
		super();
		this.quantidade = quantidade;
		this.data = data;
		this.fonteDeConsumo = fonteDeConsumo;
	}
	
	
}
