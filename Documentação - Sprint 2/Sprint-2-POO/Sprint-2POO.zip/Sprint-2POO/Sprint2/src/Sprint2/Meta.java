package Sprint2;

public class Meta {

	private String descricao;
	private String dataEntrada;
	private String dataPrevista;
	private String dataConclusao;
	
	
	
	
	public Meta(String descricao, String dataEntrada, String dataPrevista, String dataConclusao) {
		super();
		this.descricao = descricao;
		this.dataEntrada = dataEntrada;
		this.dataPrevista = dataPrevista;
		this.dataConclusao = dataConclusao;
	}
	
	
	
}
