package Sprint2;

public class Risco {

	private String descricao;
	private String impacto;
	private int urgencia;
	

}
