package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import Consumidor.Consumidor;
import sistema.conexao.Conexao;

public class FuncionarioDAO {


	private PreparedStatement ps;
	private ResultSet rs;
	private String sql;
	private Conexao conexao;

	public FuncionarioDAO() {
		conexao = new Conexao();
	}
	

	public void inserir(int idFuncionario, int cpf, String nome, String sobrenome, int telefone, String email,
			String cor, String estadoCivil, String genero, String sexualidade) {
		sql = "INSERT INTO CONSUMIDOR VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		try(Connection connection = conexao.conectar()){
			ps = connection.prepareStatement(sql);
			ps.setInt(1, idFuncionario);
			ps.setInt(2, cpf);
			ps.setString(3, nome);
			ps.execute();
			ps.close();
		}catch(SQLException e) {
			System.out.println("Erro ao insirir elemento "+e);
		}
		
	}
	
	public List<Consumidor> pesquisar(Consumidor consumidor) {
		sql = "SELECT * FROM CONSUMIDOR WHERE COD_USUARIO = ? OR NOME = ?";
		List<Consumidor> lista = new ArrayList();
		try(Connection connection = conexao.conectar()){
			ps = connection.prepareStatement(sql);
			ps.setInt(1, consumidor.getCodConsumidor());
			ps.setString(2, consumidor.getNome());
			rs = ps.executeQuery(sql);
			ps.close();
			while(rs.next()) {
				lista.add(new Consumidor(rs.getInt("Cod_Consumidor"), rs.getString("Nome"), rs.getString("Origem_contato")));
			}
		}catch(SQLException e) {
			System.out.println("Erro ao pesquisar elemento"+e);
		}
		return lista;
	}
	
	
	public void excluir(int id) {
		sql = "DELETE FROM CONSUMIDOR WHERE COD_CONSUMIDOR = ?";
		try(Connection connection = conexao.conectar()){
			ps = connection.prepareStatement(sql);
			ps.setInt(1, id);
			ps.execute();
			ps.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Erro ao excluir " + e);
		}
	
	}
}
