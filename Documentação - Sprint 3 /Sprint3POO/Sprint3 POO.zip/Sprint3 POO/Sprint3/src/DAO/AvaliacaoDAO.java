package DAO;
import sistema.conexao.*;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import Sprint2.Consumidor;
import Sprint2.Avaliacao;
import Sprint2.TipoAvaliacao;
import sistema.conexao.Conexao;

public class AvaliacaoDAO {

	private PreparedStatement ps;
	private ResultSet rs;
	private String sql;
	private Conexao conexao;

	public AvaliacaoDAO() {
		conexao = new Conexao();
	}

	public int inserir(Avaliacao mensagem) {
		int nextId=nextId();
		sql = "insert into Avaliacao values(?, ?, CURRENT_TIMESTAMP, null, ?, ?, null)";
		try(Connection connection = conexao.conectar()){
			ps = connection.prepareStatement(sql);
			ps.setInt(1, nextId);
			ps.setString(2, mensagem.getTexto());
			ps.setInt(3, mensagem.getidConsumidor());
			ps.setInt(4, mensagem.getIdMotivo());
			ps.execute();
			ps.close();
			connection.close();
		}catch(SQLException e) {
			System.out.println("Erro ao insirir tipo "+e);
		}
		return nextId;
	}
	
	public int nextId() {
		int i=1;
		sql = "SELECT cod_avaliacao + 1 as valor FROM Avaliacao WHERE ROWNUM = 1 ORDER BY cod_avaliacao DESC";
		try(Connection connection = conexao.conectar()){
			ps = connection.prepareStatement(sql);
			rs= ps.executeQuery();
			if (rs.next()) 
				i= rs.getInt("valor");
			else
				i=1;
		}catch(SQLException e) {
			System.out.println("Erro ao pegar proximo id de tipo "+e);
		}
		return i;
	}
	
	
	public Avaliacao pesquisarId(int idMensagem) {
		sql = "SELECT mensagem, cod_usuario, cod_Tipo FROM Avaliacao WHERE cod_avaliacao = ?";
		Avaliacao mensagem = new Avaliacao();
		ConsumidorDAO consumidor = null;
		try(Connection connection = conexao.conectar()){
			ps = connection.prepareStatement(sql);
			ps.setInt(1, idMensagem);
			rs = ps.executeQuery();
			while(rs.next()) {
				mensagem = new Avaliacao(rs.getString("MENSAGEM"),rs.getInt("COD_USUARIO"),rs.getInt("COD_TIPO"));
			}
			ps.close();
		}catch(SQLException e) {
			System.out.println("Erro ao pesquisar mensagem "+e);
		}
		return mensagem;
	}
	
	public List listar() {
		List<Avaliacao> lista = new ArrayList<>();
		sql = "select * from Avaliacao order by id";
		
		try(Connection connection = conexao.conectar()) {
			ps = connection.prepareStatement(sql);
			rs = ps.executeQuery();
			while(rs.next()) {
				lista.add(new Avaliacao(rs.getInt("cod_avaliacao"), rs.getString("mensagem"), rs.getInt("cod_tipo")));
			}
			
		} catch (SQLException e) {
			System.out.println("Erro ao listar departamento\n" + e);
		}		
		return lista;
	}
	
	public List<Avaliacao> listarPorTipoSemResposta(int tipo) {
		List<Avaliacao> lista = new ArrayList<>();
		sql = "select * from Avaliacao t0\r\n"
				+ "inner join tipoAvaliacao t1 on t0.cod_tipo = t1.cod_tipo\r\n"
				+ "left join Resposta t2 on t0.cod_Avaliacao = t2.cod_Avaliacao\r\n"
				+ "where t1.cod_tipo = ? and t2.cod_resposta is null\r\n"
				+ "order by t0.cod_avaliacao";
		
		try(Connection connection = conexao.conectar()) {
			ps = connection.prepareStatement(sql);
			ps.setInt(1, tipo);
			rs = ps.executeQuery();
			while(rs.next()) {
				lista.add(new Avaliacao(rs.getInt("cod_avaliacao"), rs.getString("mensagem"), rs.getInt("cod_tipo")));
			}
			ps.close();
			connection.close();
		} catch (SQLException e) {
			System.out.println("Erro ao listar departamento\n" + e);
		}		
		return lista;
	}
	
	
	
	
	public void excluir(int id) {
		sql = "DELETE FROM Avaliacao WHERE COD_avaliacao = ?";
		try(Connection connection = conexao.conectar()){
			ps = connection.prepareStatement(sql);
			ps.setInt(1, id);
			ps.execute();
			ps.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Erro ao excluir mensagem " + e);
		}
		
	}


	
	
	
	
	
	
}
