package DAO;
import sistema.conexao.*;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import Sprint2.Consumidor;
import Sprint2.TipoAvaliacao;
import sistema.conexao.Conexao;

public class ConsumidorDAO {

	private PreparedStatement ps;
	private ResultSet rs;
	private String sql;
	private Conexao conexao;

	public ConsumidorDAO() {
		conexao = new Conexao();
	}

	public int inserir(Consumidor consumidor) {
		int nextId=nextId();
		sql = "insert into consumidor values(?, ?, ?)";
		try(Connection connection = conexao.conectar()){
	        ps = connection.prepareStatement(sql);
	        ps.setInt(1, nextId);
	        ps.setString(2, consumidor.getNome());
	        ps.setString(3, consumidor.getOrigemDoContato());
	        ps.execute();
			ps.close();
			connection.close();
		}catch(SQLException e) {
			System.out.println("Erro ao insirir consumidores "+e);
		}
		return nextId;
	}
	
	public int nextId() {
		int i=1;
		sql = "SELECT COD_USUARIO + 1 as valor FROM CONSUMIDOR WHERE ROWNUM = 1 ORDER BY COD_USUARIO DESC";
		try(Connection connection = conexao.conectar()){
			ps = connection.prepareStatement(sql);
			rs= ps.executeQuery();
			if (rs.next()) 
				i= rs.getInt("valor");
			connection.close();
		}catch(SQLException e) {
			System.out.println("Erro ao pegar proximo id de consumidor "+e);
		}
		return i;
	}
	
	public List<Consumidor> pesquisar(int idConsumidor, String nome) {
		sql = "SELECT * FROM SPRINT3_CONSUMIDOR WHERE ID_USUARIO = ? OR NOME = ?";
		List<Consumidor> lista = new ArrayList();
		try(Connection connection = conexao.conectar()){
			ps = connection.prepareStatement(sql);
			ps.setInt(1, idConsumidor);
			ps.setString(2, nome);
			rs = ps.executeQuery(sql);
			ps.close();
			connection.close();
			while(rs.next()) {
				lista.add(new Consumidor(rs.getInt("ID_CONSUMIDOR"), rs.getString("NOME"), rs.getString("ORIGEM_CONTATO")));
			}
		}catch(SQLException e) {
			System.out.println("Erro ao pesquisar elemento"+e);
		}
		return lista;
	}
	
	
	public Consumidor pesquisarId(int idConsumidor) {
		sql = "SELECT * FROM SPRINT3_CONSUMIDOR WHERE ID_USUARIO = ?";
		Consumidor consumidor = null;
		try(Connection connection = conexao.conectar()){
			ps = connection.prepareStatement(sql);
			ps.setInt(1, idConsumidor);
			rs = ps.executeQuery(sql);
			ps.close();
			connection.close();
			while(rs.next()) {
				consumidor = new Consumidor(rs.getInt("ID_CONSUMIDOR"), rs.getString("NOME"), rs.getString("ORIGEM_CONTATO"));
			}
		}catch(SQLException e) {
			System.out.println("Erro ao pesquisar elemento"+e);
		}
		return consumidor;
	}
	
	
	
	public void excluir(int id) {
		sql = "DELETE FROM SPRINT3_CONSUMIDOR WHERE ID_CONSUMIDOR = ?";
		try(Connection connection = conexao.conectar()){
			ps = connection.prepareStatement(sql);
			ps.setInt(1, id);
			ps.execute();
			ps.close();
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Erro ao excluir " + e);
		}
		
	}
	
	public void alterar(int id, String nome, String email, int telefone) {
		sql = "ALTER CONSUMIDOR SET NOME = ?, EMAIL = ?, TELEFONE = ? WHERE ID_CONSUMIDOR = ?";
		try(Connection connection = conexao.conectar()){
			ps = connection.prepareStatement(sql);
			ps.setString(1, nome);
			ps.setString(1, email);
			ps.setInt(3, telefone);
			ps.setInt(4, id);
			ps.execute();
			ps.close();
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Erro ao excluir " + e);
		}
		
	}
	
	
	
	
	
	
}
