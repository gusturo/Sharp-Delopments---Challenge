package DAO;

import Sprint2.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import Sprint2.*;
import sistema.conexao.Conexao;

public class RespostaDAO {

	private PreparedStatement ps;
	private ResultSet rs;
	private String sql;
	private Conexao conexao;
	
	
	public RespostaDAO() {
		conexao = new Conexao();
	}
	
	
	public int inserir(Resposta resposta) {
		int nextId=nextId();
		sql = "insert into Resposta values(?, ?, ?)";
		try(Connection connection = conexao.conectar()){
			ps = connection.prepareStatement(sql);
			ps.setInt(1, nextId);
			ps.setInt(2, resposta.getCod_avaliacao());
			ps.setString(3, resposta.getMensagem());
			ps.execute();
			ps.close();
			connection.close();
		}catch(SQLException e) {
			System.out.println("Erro ao insirir tipo "+e);
		}
		return nextId;
	}
	
	
	public int nextId() {
		int i=1;
		sql = "SELECT cod_resposta + 1 as valor FROM Resposta WHERE ROWNUM = 1 ORDER BY cod_resposta DESC";
		try(Connection connection = conexao.conectar()){
			ps = connection.prepareStatement(sql);
			rs= ps.executeQuery();
			if (rs.next()) 
				i= rs.getInt("valor");
			else
				i=1;
			connection.close();
		}catch(SQLException e) {
			System.out.println("Erro ao pegar proximo id de tipo "+e);
		}
		return i;
	}
	
	
	public String listar() {
		String aux="";
		sql = "select t0.cod_avaliacao, t0.mensagem, t1.resposta from Avaliacao t0 \r\n"
				+ "left join resposta t1 on t0.cod_Avaliacao = t1.cod_Avaliacao";
		
		try(Connection connection = conexao.conectar()) {
			ps = connection.prepareStatement(sql);
			rs = ps.executeQuery();
			while(rs.next()) {
				if(rs !=null)
				aux+="\n"+rs.getInt("cod_avaliacao") +"-Problema:"+ rs.getString("mensagem")+"\nResposta:"+ rs.getString("resposta");
			}
			ps.close();
			connection.close();
		} catch (SQLException e) {
			System.out.println("Erro ao listar departamento\n" + e);
		}		
		return aux;
	}
	
	
	
	
	
	
	
	
}
