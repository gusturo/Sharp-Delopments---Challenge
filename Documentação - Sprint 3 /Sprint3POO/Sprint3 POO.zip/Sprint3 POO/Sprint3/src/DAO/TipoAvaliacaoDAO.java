package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import Sprint2.Consumidor;
import Sprint2.*;
import sistema.conexao.Conexao;

public class TipoAvaliacaoDAO {

	private PreparedStatement ps;
	private ResultSet rs;
	private String sql;
	private Conexao conexao;
	
	public TipoAvaliacaoDAO() {
		conexao = new Conexao();
	}
	
	
	public int inserir(TipoAvaliacao TipoAvaliacao) {
		int nextId=nextId();
		sql = "INSERT INTO TipoAvaliacao VALUES(? , ?)";
		try(Connection connection = conexao.conectar()){
			ps = connection.prepareStatement(sql);
			ps.setInt(1, nextId);
			ps.setString(2, TipoAvaliacao.getMotivo());
			ps.execute();
			ps.close();
			connection.close();
		}catch(SQLException e) {
			System.out.println("Erro ao insirir tipo "+e);
		}
		return nextId;
	}
	
	public int nextId() {
		int i=1;
		sql = "SELECT COD_TIPO + 1 as valor FROM TipoAvaliacao WHERE ROWNUM = 1 ORDER BY COD_TIPO DESC";
		try(Connection connection = conexao.conectar()){
			ps = connection.prepareStatement(sql);
			rs= ps.executeQuery();
			if (rs.next()) 
				i= rs.getInt("valor");
		}catch(SQLException e) {
			System.out.println("Erro ao pegar proximo id de tipo "+e);
		}
		return i;
	}
	
	
	
	public List<TipoAvaliacao> listar() {
		sql = "SELECT * FROM TipoAvaliacao";
		List<TipoAvaliacao> lista = new ArrayList();
		try(Connection connection = conexao.conectar()){
			ps = connection.prepareStatement(sql);
			rs = ps.executeQuery(sql);
			while(rs.next()) {
				lista.add(new TipoAvaliacao(rs.getInt("COD_TIPO"), rs.getString("NOME")));
			}
			ps.close();
			connection.close();
		}catch(SQLException e) {
			System.out.println("Erro ao pesquisar elemento"+e);
		}
		return lista;
	}
	
	
	
	
	public void excluir(int id) {
		sql = "DELETE FROM TipoAvaliacao WHERE COD_TIPO = ?";
		try(Connection connection = conexao.conectar()){
			ps = connection.prepareStatement(sql);
			ps.setInt(1, id);
			ps.execute();
			ps.close();
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Erro ao excluir " + e);
		}
		
	}


	public boolean existe(int id) {
		sql = "Select cod_Tipo from tipoAvaliacao where cod_Tipo=?";
		try(Connection connection = conexao.conectar()){
			ps = connection.prepareStatement(sql);
			ps.setInt(1, id);
			rs=ps.executeQuery();
			if(rs.next()) {
				return true;
			}
			ps.close();
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Erro ao excluir " + e);
		}
		return false;
	}
	
	
	
}
