package Sprint2;

public class Avaliacao {

	private int IdAvaliacao;
	private String texto;
	private String dataMensagem;
	private String dataConclusao;
	private int idTipoFeedback;
	private int idConsumidor;
	
	
	public Avaliacao() {
	}
	
	public Avaliacao(int IdAvaliacao, String texto, int idTipoFeedback) {
		super();
		this.IdAvaliacao = IdAvaliacao;
		this.texto = texto;
		this.idTipoFeedback = idTipoFeedback;
	}
	
	public Avaliacao(String texto,int idTipoFeedback, int idConsumidor) {
		super();
		this.texto = texto;
		this.idTipoFeedback = idTipoFeedback;
		this.idConsumidor = idConsumidor;
	}

	public Avaliacao(int idConsumidorn, String texto) {
		super();
		this.texto = texto;
		this.idConsumidor = idConsumidorn;
	}

	public String getTexto() {
		return texto;
	}


	public void setTexto(String texto) {
		this.texto = texto;
	}


	public int getidConsumidor() {
		return idConsumidor;
	}


	public void setidConsumidor(int idConsumidor) {
		this.idConsumidor = idConsumidor;
	}


	


	public int getIdAvaliacao() {
		return IdAvaliacao;
	}

	public void setIdAvaliacao(int idAvaliacao) {
		IdAvaliacao = idAvaliacao;
	}

	public int getIdMotivo() {
		return idTipoFeedback;
	}

	public void setIdMotivo(int idMotivo) {
		this.idTipoFeedback = idMotivo;
	}

	public String getDataMensagem() {
		return dataMensagem;
	}


	public void setDataMensagem(String data) {
		this.dataMensagem = data;
	}
	
	

	
	
	
	
	
	
	
}
