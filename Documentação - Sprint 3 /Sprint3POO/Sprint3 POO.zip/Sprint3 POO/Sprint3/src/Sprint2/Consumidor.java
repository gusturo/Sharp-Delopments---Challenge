package Sprint2;

public class Consumidor {

	private int idConsumidor;
	private String nome;
	private String origemDoContato;
	
	public Consumidor() {
	}
	
	public Consumidor(int idConsumidor, String nome, String origemDoContato) {
		super();
		this.nome = nome;
		this.origemDoContato = origemDoContato;
		this.idConsumidor = idConsumidor;
	}
	
	public Consumidor(String nome, String origemDoContato) {
		super();
		this.nome = nome;
		this.origemDoContato = origemDoContato;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public int getIdConsumidor() {
		return idConsumidor;
	}

	public void setIdConsumidor(int idConsumidor) {
		this.idConsumidor = idConsumidor;
	}
	
	
	public String getOrigemDoContato() {
		return origemDoContato;
	}

	public void setOrigemDoContato(String origemDoContato) {
		this.origemDoContato = origemDoContato;
	}

	public String getDados() {
		return "\n"+"Consumidor:"
		+"\n Nome:"+nome
		+"\n Origem do contato:"+origemDoContato
		+"\n ID funcionario: "+idConsumidor;
	}
}
