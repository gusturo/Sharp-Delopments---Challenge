package Sprint2;

public class Resposta {
	int cod_resposta ;
    int cod_avaliacao ;
    String mensagem;
    
    
	public Resposta(int cod_avaliacao, String mensagem) {
		super();
		this.cod_avaliacao = cod_avaliacao;
		this.mensagem = mensagem;
	}
    
	public Resposta(int cod_resposta, int cod_avaliacao, String mensagem) {
		super();
		this.cod_resposta = cod_resposta;
		this.cod_avaliacao = cod_avaliacao;
		this.mensagem = mensagem;
	}


	public Resposta() {
		// TODO Auto-generated constructor stub
	}

	public int getCod_resposta() {
		return cod_resposta;
	}


	public void setCod_resposta(int cod_resposta) {
		this.cod_resposta = cod_resposta;
	}


	public int getCod_avaliacao() {
		return cod_avaliacao;
	}


	public void setCod_avaliacao(int cod_avaliacao) {
		this.cod_avaliacao = cod_avaliacao;
	}


	public String getMensagem() {
		return mensagem;
	}


	public void setMensagem(String mensagem) {
		this.mensagem = mensagem;
	}
    
    
    

    
	
}
