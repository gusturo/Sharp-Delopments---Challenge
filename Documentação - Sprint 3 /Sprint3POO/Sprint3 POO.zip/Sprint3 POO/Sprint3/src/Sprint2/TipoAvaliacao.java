package Sprint2;

public class TipoAvaliacao {
	private int idTipo;
	private String motivo;
	
	public TipoAvaliacao(int idTipo, String motivo) {
		super();
		this.idTipo = idTipo;
		this.motivo = motivo;
	}
	
	public TipoAvaliacao(String motivo) {
		super();
		this.motivo = motivo;
	}
	
	public TipoAvaliacao() {
		// TODO Auto-generated constructor stub
	}

	public int getidTipo() {
		return idTipo;
	}
	public void setidTipo(int idTipo) {
		this.idTipo = idTipo;
	}
	public String getMotivo() {
		return motivo;
	}
	public void setMotivo(String motivo) {
		this.motivo = motivo;
	}
	
	
	
	
	
}
