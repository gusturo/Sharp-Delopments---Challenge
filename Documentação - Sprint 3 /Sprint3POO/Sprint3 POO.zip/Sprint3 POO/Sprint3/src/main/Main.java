

//PARTICIPANTES DO GRUPO:
//Rafael Fiel Cruz Miranda - RM94654
//Erik Hoon Ko - RM93599
//Fernanda Freitas - RM95465
//Giovana Arruda da Costa - RM94584
//Gabrielly Fabricio Ramos - RM95413

package main;


import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import DAO.*;
import Sprint2.*;

import static java.lang.Integer.parseInt;
import static java.lang.Long.parseLong;
import static javax.swing.JOptionPane.showInputDialog;
import static javax.swing.JOptionPane.showMessageDialog;

public class Main {

		static  Random random = new Random();
		
 		public static void main(String[] args) {
			int opcaoMenu;
			
			do {
				opcaoMenu = parseInt(showInputDialog(gerarMenu()));
				if(opcaoMenu < 1 || opcaoMenu > 4) {
					showMessageDialog(null, "Opcao invalida");
				} else {
					switch(opcaoMenu) {
						case 1:
							showMessageDialog(null, "Programa encerrado");
							break;
						case 2:
							receberFeedback();
							break;
						case 3:			            	
							atenderFeedback();
							break;
						case 4:
							exibirTudo();
							break;
					}
				}
	        } while(opcaoMenu != 1);
		}
		
		public static void receberFeedback() {
			Consumidor consumidor = new Consumidor();
			ConsumidorDAO consumidorDAO=new ConsumidorDAO();
			Avaliacao feedback=new Avaliacao();
			AvaliacaoDAO feedbackDAO=new AvaliacaoDAO();
			TipoAvaliacao tipo=new TipoAvaliacao();
			TipoAvaliacaoDAO tipoDAO=new TipoAvaliacaoDAO();
			int idConsumidor=0;
			int idMotivo=0;
			
		    consumidor.setNome(showInputDialog("Digite seu nome:"));
		    
		    consumidor.setOrigemDoContato(showInputDialog("Digite por onde voce entra em contato:"));
			while (consumidor.getOrigemDoContato() == null) {
				consumidor.setOrigemDoContato(showInputDialog("Digite por onde voce entra em contato:"));
			}
			List<TipoAvaliacao> lista=tipoDAO.listar();
			String aux="";
			for (int i=0; i<lista.size(); i++) {
				aux+=lista.get(i).getidTipo()+"-"+lista.get(i).getMotivo()+"\n";
			}
			idMotivo=parseInt(showInputDialog("Motivo do contato:\n"
					+ "0-Cadastrar um novo\n"+aux
					));
					tipo.setidTipo(idMotivo);
			if(tipo.getidTipo() == 0 || !tipoDAO.existe(tipo.getidTipo())) {
				tipo.setMotivo(showInputDialog("Insira o motivo:"));
				idMotivo=tipoDAO.inserir(tipo);
			feedback.setIdMotivo(idMotivo);
			}
			feedback.setTexto(showInputDialog("Digite a mensagem:"));
			while (feedback.getTexto() == null) {
				feedback.setTexto(showInputDialog("Informacao obrigatoria, campo nao pode ficar em branco!\nDigite o texto:"));
			}

			//sucesso
			idConsumidor=consumidorDAO.inserir(consumidor);

			feedback.setidConsumidor(idConsumidor);
			int idFeedback=feedbackDAO.inserir(feedback);
			
			
			showMessageDialog(null, "Obrigado por contribuir com sua Feedback\nVoce recebera um codigo de protocolo para identificar a conversa\nSeu codigo: "+idFeedback);	
				
			}
		
		public static void atenderFeedback() {
			AvaliacaoDAO avaliacaoDAO=new AvaliacaoDAO();
			TipoAvaliacaoDAO tipoDAO=new TipoAvaliacaoDAO();
			Resposta resp = new Resposta();
			RespostaDAO respDAO = new RespostaDAO();
			List<Avaliacao> avaliacao = new ArrayList();
			List<Consumidor> consumidor=new ArrayList();
			List<TipoAvaliacao> motivo=new ArrayList();
			motivo=tipoDAO.listar();
			String aux="";
			
			for(int i=0; i<motivo.size(); i++) {
				aux+=motivo.get(i).getidTipo()+"-"+motivo.get(i).getMotivo()+"\n";
			}
			int tipo=parseInt(showInputDialog(null, "Qual tipo de mensagem quer responder:\n"+aux));
			
			avaliacao=avaliacaoDAO.listarPorTipoSemResposta(tipo);
			aux="";
			for(int i=0; i<avaliacao.size(); i++) {
				aux+=avaliacao.get(i).getIdAvaliacao()+"-"+avaliacao.get(i).getTexto()+"\n";
			}
			int excluir = parseInt(showInputDialog(null, "Qual mensagem voce quer responder:\n"+aux));
			String resposta=showInputDialog(avaliacaoDAO.pesquisarId(excluir).getTexto()+"\n Resposta:");
			respDAO.inserir(new Resposta(excluir, resposta));
			
		}
		
		
		public static void exibirTudo() {
			RespostaDAO resp=new RespostaDAO();
			showMessageDialog(null, resp.listar());
		}
		
	
		public static String gerarMenu() {
			String aux = "\nBem vindo ao canal de comunicacao\n";
			aux += "\n";
			aux += "Selecione uma das opcoes abaixo:\n";
			aux += "1. Encerrar programa\n";
			aux += "2. Enviar Feedback\n";
			aux += "3. Atender Feedback\n";
			aux += "4. Exibir tudo\n";
			return aux;
		}
}
